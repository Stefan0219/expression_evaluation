 Notes for reading and running my project:
       I chose to code in Linux environment.
       But the Chinese IME somehow is unavailable in the IDE which I am currently using.
       So most of the comments are written in English.
       The Chinese comments come from the project which I used done.
       If there is any problem in running my program, please email me at tpq0219@qq.com.
       Best wishes.




 Notes for git's branches:
        The branches which named in English are not fully implemented with all functions since
        they were branched during coding.
        The branches which named in Chinese pinyin are used for thesis defence. They both
        branched form the master. The differences between these branches are just in the
        main function.
